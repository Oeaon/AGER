package com.example.ager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.ager.databinding.ActivityBeneficiosBinding;
import com.example.ager.databinding.ActivityEmployersBinding;
import com.example.ager.databinding.ActivityMainBinding;
import com.example.ager.databinding.ActivityParticularesBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BeneficiosActivity extends AppCompatActivity {

    ActivityBeneficiosBinding binding;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbxwqG28FQi35OWyD_3xyx8neNWIfhWITe8oOAlJiGAsJ_X0-9i-1D2p9Qv3BUSQPzY/exec?action=getBeneficios";

    private Adaptador adaptador;

    private ParkingDataModel parkingDataModel;

    Button btnMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBeneficiosBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        adaptador= new Adaptador(this);

        binding.BeneficiosDataRecycler.setAdapter(adaptador);
        binding.BeneficiosDataRecycler.setLayoutManager(new LinearLayoutManager(this));

        btnMenu = findViewById(R.id.btn_menuBeneficios);


        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (BeneficiosActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


        getDataParticulares();
    }



    private void getDataParticulares(){
        String url=SCRIPT_WEB_URL;
        JsonObjectRequest  jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("items");

                    //recorre todos los objetos del array
                    for (int i=0; i<jsonArray.length();i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);



                        //Columnas
                        String idPlaza = jsonObject.getString("nombre");
                        String nombre = jsonObject.getString("beneficio/perdida_mensual");
                        String precio = jsonObject.getString("beneficio/perdida_trimestral");
                        String particular = jsonObject.getString("beneficio/perdida_anual");

                        ParkingDataModel parkingDataModel = new ParkingDataModel(idPlaza,"\n MENSUAL: "+nombre,"\n TRIMESTRAL: "+precio,"\n ANUAL: "+particular);

                        adaptador.addModel(parkingDataModel);
                    }


                } catch (JSONException e) {
                    Toast.makeText(BeneficiosActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(BeneficiosActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

    }

}