package com.example.ager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.ager.databinding.ActivityBeneficiosBinding;
import com.example.ager.databinding.ActivityEmployersBinding;
import com.example.ager.databinding.ActivityMainBinding;
import com.example.ager.databinding.ActivityParticularesBinding;
import com.example.ager.databinding.ActivityTotalBinding;
import com.example.ager.databinding.ActivityTrabajadoresBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TrabajadoresActivity extends AppCompatActivity {

    ActivityTrabajadoresBinding binding;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbx-FIZtKGet1gRH1J88EA1q3V80PsJyzQv4RAenM4AYxdzJa3YL7EBwUqwn-myRlVXu/exec?action=getEmpleados";

    private Adaptador adaptador;

    private ParkingDataModel parkingDataModel;

    Button btnMenu, btnAddCurrante,btnModificarCurrante;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTrabajadoresBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        adaptador= new Adaptador(this);

        binding.TrabajadoresDataRecycler.setAdapter(adaptador);
        binding.TrabajadoresDataRecycler.setLayoutManager(new LinearLayoutManager(this));

        btnMenu = findViewById(R.id.btn_menuTrabajadores);
        btnAddCurrante=findViewById(R.id.btn_addCurrante);
        btnModificarCurrante=findViewById(R.id.btn_editar_trabajador);
        getDataTrabajadores();


        btnModificarCurrante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TrabajadoresActivity.this, UpdateEmpleadoActivity.class);
                startActivity(intent);
            }
        });

        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (TrabajadoresActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btnAddCurrante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (TrabajadoresActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });


    }



    private void getDataTrabajadores(){
        String url=SCRIPT_WEB_URL;
        JsonObjectRequest  jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("items");

                    //recorre todos los objetos del array
                    for (int i=0; i<jsonArray.length();i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        //Columnas
                        String dni = jsonObject.getString("dni");
                        String nombre = jsonObject.getString("nombre");
                        String cargo = jsonObject.getString("cargo");
                        String nota = jsonObject.getString("nota");
                        String ingresoMensual = jsonObject.getString("ingreso_mensual");
                        String ingresoTrimestral = jsonObject.getString("ingreso_trimestral");
                        String ingresoAnual = jsonObject.getString("ingreso_anual");

                        ParkingDataModel parkingDataModel = new ParkingDataModel("DNI: "+dni,"Nombre: "+nombre,"Cargo: "+cargo,"Nota: "+nota,"Ingreso mensual: "+ingresoMensual+"€","Ingreso trimestral: "+ingresoTrimestral+"€","Ingreso anual: "+ingresoAnual+"€");

                        adaptador.addModel(parkingDataModel);

                    }


                } catch (JSONException e) {
                    Toast.makeText(TrabajadoresActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(TrabajadoresActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

    }

}