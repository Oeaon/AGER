package com.example.ager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ager.databinding.ActivityUpdateDataParkingBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Struct;

public class UpdateDataParkingActivity extends AppCompatActivity {

    ActivityUpdateDataParkingBinding binding;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbx-FIZtKGet1gRH1J88EA1q3V80PsJyzQv4RAenM4AYxdzJa3YL7EBwUqwn-myRlVXu/exec?action=getParking";
    private String SCRIPT_UPDATE="https://script.google.com/macros/s/AKfycbxs6bzvHsI9qRYLyziKq58Mr5DGXWr6elMZWXwXoVLlc4H3nKc0JCDZTo_XPmWjrXdI/exec?action=updateParking";

    int [] ArrayDePlazas= new int[200];

    boolean flagEsta;

    ProgressDialog progressDialog;

    private ParkingDataModel parkingDataModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding=ActivityUpdateDataParkingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        rellenarLista();

        progressDialog = new ProgressDialog(UpdateDataParkingActivity.this);
        progressDialog.setMessage("Actualizando...");

        //parkingDataModel=(ParkingDataModel) getIntent().getSerializableExtra("model");

       // binding.EtNombreParkingUpdate.setText(parkingDataModel.getNombre());
       // binding.EtPrecioParkingUpdate.setText(parkingDataModel.getPrecio());

        binding.btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                progressDialog.hide();
            }
        });

        binding.btnActualizarUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    //Declaramos variables
                    String idPlaza=binding.EtIdParkingUpdate.getText().toString();
                    String nombre= binding.EtNombreParkingUpdate.getText().toString();
                    String precio= binding.EtPrecioParkingUpdate.getText().toString();
                    String tipo="";

                    if (binding.rbParticularUpdate.isChecked()){
                        tipo="VERDADERO";
                    }
                    else  if (binding.rbEmpresaUpdate.isChecked()){
                        tipo="FALSO";
                    }
                    final String finalTipo=tipo;

                  //  parkingDataModel.setNombre(nombre);
                   // parkingDataModel.setPrecio(precio);
                   // parkingDataModel.setParticular(tipo);

                    //Rellenamos la lista de parking
                    rellenarLista();

                    if (!idPlaza.isEmpty()){
                        //Comprobamos que no sea igual
                        comprobarIdNuevo(idPlaza);
                    }
                    //ALERT DIALOG

                    if (idPlaza.isEmpty()){

                        AlertDialog.Builder builder = new AlertDialog.Builder(UpdateDataParkingActivity.this);
                        builder.setTitle("ATENCIÓN");
                        builder.setMessage("Indique el número del parking a actualizar, por favor.");
                        builder.setPositiveButton("Aceptar", null);
                        AlertDialog dialog = builder.create();
                        dialog.show();

                    }


                    else if (Integer.parseInt(idPlaza)>200){


                        AlertDialog.Builder builder = new AlertDialog.Builder(UpdateDataParkingActivity.this);
                        builder.setTitle("ATENCIÓN");
                        builder.setMessage("El NÚMERO de la plaza de parking es incorrecto.\nPor favor, recuerde que nuestro límite de plazas es de 200.");
                        builder.setPositiveButton("Aceptar", null);

                        AlertDialog dialog = builder.create();
                        dialog.show();


                    }
                    else if (!flagEsta){


                        AlertDialog.Builder builder = new AlertDialog.Builder(UpdateDataParkingActivity.this);
                        builder.setTitle("CUIDADO");
                        builder.setMessage("Lo sentimos, pero esa plaza no pertenece a nuestro parking.\nPor favor, inténtelo con otra.");
                        builder.setPositiveButton("Aceptar", null);

                        AlertDialog dialog = builder.create();
                        dialog.show();
                    }

                    else if (nombre.isEmpty()){
                        AlertDialog.Builder builder = new AlertDialog.Builder(UpdateDataParkingActivity.this);
                        builder.setTitle("ATENCIÓN");
                        builder.setMessage("Rellene el nombre del cliente, por favor.");
                        builder.setPositiveButton("Aceptar", null);

                        AlertDialog dialog = builder.create();
                        dialog.show();
                    }

                    else if (precio.isEmpty()){
                        AlertDialog.Builder builder = new AlertDialog.Builder(UpdateDataParkingActivity.this);
                        builder.setTitle("ATENCIÓN");
                        builder.setMessage("Rellene el precio a cobrar, por favor. ");
                        builder.setPositiveButton("Aceptar", null);

                        AlertDialog dialog = builder.create();
                        dialog.show();
                    }

                    if (idPlaza.length()>0&&nombre.length()>0 &&precio.length()>0&&Integer.parseInt(idPlaza)<=200&&flagEsta){
                        progressDialog.show();
                        updateDataParking(idPlaza,nombre,precio,finalTipo);
                    }



                }
            }
        });
    }

    private void updateDataParking(String idPlaza,String nombre, String precio, String tipo) {
        String url=SCRIPT_UPDATE+"&idPlaza="+idPlaza+"&nombre="+nombre+"&precio="+precio+"&particular="+tipo;

        StringRequest stringRequest= new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent intent = new Intent(getApplicationContext(), UpdateSuccessActivity.class);
                startActivity(intent);
                progressDialog.hide();
                //Toast.makeText(UpdateDataParkingActivity.this,response,Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(UpdateDataParkingActivity.this,error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }


    //MÉTODOS
    public void rellenarLista(){
        String url=SCRIPT_WEB_URL;
        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("items");

                    //recorre todos los objetos del array
                    for (int i=0; i<jsonArray.length();i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        //Columnas
                        String idPlaza =jsonObject.getString("idPlaza");
                        ArrayDePlazas[i] =Integer.parseInt(idPlaza);




                    }


                } catch (JSONException e) {
                    Toast.makeText(UpdateDataParkingActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(UpdateDataParkingActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

    }

    public boolean comprobarIdNuevo(String idPlaza){

        for (int i=0; i<ArrayDePlazas.length;i++){
            if (Integer.parseInt(idPlaza)!=ArrayDePlazas[i]){
                flagEsta=false;

            }else{
              return flagEsta= true;
            }
        }
        return flagEsta;
    }
}