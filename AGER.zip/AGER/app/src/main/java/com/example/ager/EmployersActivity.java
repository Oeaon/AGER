package com.example.ager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.ager.databinding.ActivityEmployersBinding;
import com.example.ager.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EmployersActivity extends AppCompatActivity {

    
    ActivityEmployersBinding binding;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbxcmLOgtxewryiBa29VTU_11Hqiy03lT89JViGQPyNW-YuExo_KK8rkUwNa3ekFJJH0/exec?action=getParking";

    private Adaptador adaptador;

    private ParkingDataModel parkingDataModel;

    Button btnListarEmpresas, btnListarParticulares, btnTotal,btn_modificar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEmployersBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        adaptador= new Adaptador(this);

        binding.parkingDataRecycler.setAdapter(adaptador);
        binding.parkingDataRecycler.setLayoutManager(new LinearLayoutManager(this));

        btnListarEmpresas = findViewById(R.id.btn_empresas);
        btnListarParticulares = findViewById(R.id.btn_particulares);
        btnTotal  = findViewById(R.id.btn_total);
        btn_modificar=findViewById(R.id.btn_modificarParking);
        btnListarEmpresas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (EmployersActivity.this, EmpresasActivity.class);
                startActivity(intent);
            }
        });

        btnListarParticulares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (EmployersActivity.this, ParticularesActivity.class);
                startActivity(intent);
            }
        });

        btnTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (EmployersActivity.this, TotalActivity.class);
                startActivity(intent);
            }
        });

        btn_modificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (EmployersActivity.this, UpdateDataParkingActivity.class);
                startActivity(intent);
            }
        });

        getDataParking();
    }



    private void getDataParking(){
        String url=SCRIPT_WEB_URL;
        JsonObjectRequest  jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("items");

                    //recorre todos los objetos del array
                    for (int i=0; i<jsonArray.length();i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        //Columnas
                        String idPlaza = jsonObject.getString("idPlaza");
                        String nombre = jsonObject.getString("nombre");
                        String precio = jsonObject.getString("precio");
                        String particular = jsonObject.getString("particular");

                        if (particular.equalsIgnoreCase("false")||particular.equalsIgnoreCase("falso")|| particular.equalsIgnoreCase("=false()")
                                ||particular.equalsIgnoreCase("=falso()")){
                            particular="EMPRESA";
                        }else {
                            particular="PARTICULAR";
                        }

                        ParkingDataModel parkingDataModel = new ParkingDataModel("ID plaza:  " +idPlaza,"","Propietario:  "+nombre,"","Precio:  "+precio+"€","","Tipo: "+particular);

                        adaptador.addModel(parkingDataModel);

                    }


                } catch (JSONException e) {
                    Toast.makeText(EmployersActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(EmployersActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

    }

}