package com.example.ager;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import nl.dionsegijn.konfetti.KonfettiView;
import nl.dionsegijn.konfetti.models.Shape;
import nl.dionsegijn.konfetti.models.Size;

public class UpdateSuccessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_success);

        KonfettiView viewKonfetti;
        viewKonfetti = findViewById(R.id.konfettiUpdate);

        viewKonfetti.build()
                .addColors(Color.parseColor("#08f26e"),Color.parseColor("#059142"), Color.GREEN)
                .setDirection(0.0,359.0)
                .setSpeed(1f,5f)
                .setFadeOutEnabled(true)
                .setTimeToLive(9999L)
                .addShapes(Shape.Square.INSTANCE, Shape.Circle.INSTANCE)
                .addSizes(new Size(15,5f))
                .setPosition(-50f,viewKonfetti.getWidth()+999f,-50f,-50f)
                .streamFor(400,5000L);
    }
}