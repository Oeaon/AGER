package com.example.ager;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adaptador extends RecyclerView.Adapter<Adaptador.ViewHolder>{
    private Context context;
    private List<ParkingDataModel> dataModelList;

    public Adaptador(Context context){
        this.context = context;
        dataModelList = new ArrayList<>();
    }

    public void addModel(ParkingDataModel parkingDataModel){
        dataModelList.add(parkingDataModel);
        notifyDataSetChanged();
    }

    public void clear(){
        dataModelList.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.data_row,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bindViews(dataModelList.get(position));
    }

    @Override
    public int getItemCount() {
        return dataModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView idPlaza,nombre,precio,particular,ingresoMensual,ingresoTrimestral,ingresoAnual;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            idPlaza= itemView.findViewById(R.id.idPlazaParking);
            nombre= itemView.findViewById(R.id.nombreParking);
            precio= itemView.findViewById(R.id.precioParking);
            particular= itemView.findViewById(R.id.particularParking);
            ingresoMensual=itemView.findViewById(R.id.ingMensual);
            ingresoTrimestral=itemView.findViewById(R.id.ingTrimestral);
            ingresoAnual=itemView.findViewById(R.id.ingAnual);
        }

        public void bindViews(ParkingDataModel parkingDataModel) {
            idPlaza.setText(parkingDataModel.getIdPlaza());
            nombre.setText(parkingDataModel.getNombre());
            precio.setText(parkingDataModel.getPrecio());
            particular.setText(parkingDataModel.getParticular());
            ingresoMensual.setText(parkingDataModel.getIngreso_mensual());
            ingresoTrimestral.setText(parkingDataModel.getIngreso_trimestral());
            ingresoAnual.setText(parkingDataModel.getIngreso_anual());

           /* itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context,UpdateDataParkingActivity.class);
                    intent.putExtra("model", parkingDataModel);
                    context.startActivity(intent);
                }
            });*/
        }
    }

    }
