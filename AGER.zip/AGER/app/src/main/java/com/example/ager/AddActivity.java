package com.example.ager;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddActivity extends AppCompatActivity {
    boolean repetido=false;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbzBsKptQt4cnIB-IMau6HEw4fbgIozmKtTMuJbEaDtzQe6AGwUABxOvSp7dvEvyQBxj/exec?action=addEmpleados";

    String [] ArrayDeEmpleados= new String[20];

    EditText ET_dni,ET_nombre,ET_cargo,ET_nota,ET_ingresoMensual;


    Button btnInsertar, btn_VolverMenu;

    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        rellenarLista();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        ET_dni= findViewById(R.id.editText_DNI);
        ET_nombre = findViewById(R.id.editText_nombrEmpleadoUpdate);
        ET_cargo=findViewById(R.id.editText_cargoEmpleadoUpdate);
        ET_nota=findViewById(R.id.editText_notaEmpleadoUpdate);
        ET_ingresoMensual= findViewById(R.id.editText_sueldoEmpleadoUpdate);






        btnInsertar = findViewById(R.id.btn_ActualizarEmpleadoUpdate);
        btn_VolverMenu = findViewById(R.id.btn_volverMenuEmpleadoUpdate);

        progressDialog = new ProgressDialog(AddActivity.this);
        progressDialog.setMessage("Insertando...");

       btnInsertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //ALERT DIALOG

                if (ET_dni.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Indique el DNI del trabajador, por favor.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();

                }

                else if (ET_dni.getText().toString().length()>9){
                    AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("El DNI supera las 9 cifras.\nPor favor, no supere dicho límite.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if (listaLlena()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("La lista de trabajadores ha llegado a su límite(20).\nPor favor, no supere dicho límite.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }

                else if (getRepetido()){

                    AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                    builder.setTitle("CUIDADO");
                    builder.setMessage("Lo sentimos, pero el/la trabajador/a introducida ya está contratado/a.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }



                else if (ET_nombre.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene el nombre del trabajador, por favor.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }

                else if (ET_cargo.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene el cargo a asociar, por favor. ");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if (ET_nota.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene una nota acerda del trabajador, por favor. ");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if (ET_ingresoMensual.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene un sueldo para el trabajador, por favor. ");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }



                 if (ET_dni.getText().toString().length()>0&&ET_nombre.getText().toString().length()>0 && ET_cargo.getText().toString().length()>0&& ET_nota.getText().toString().length()>0&& ET_ingresoMensual.getText().toString().length()>0&&ET_dni.getText().toString().length()<=9&&!getRepetido()){
                     progressDialog.show();
                     addEmpleados();
                     rellenarLista();
                }



            }
        });



       btn_VolverMenu.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent (AddActivity.this, MainActivity.class);
               startActivity(intent);
           }
       });
    }


    public boolean getRepetido(){
        for (int i=0; i<ArrayDeEmpleados.length;i++){
            if (ET_dni.getText().toString().equals(ArrayDeEmpleados[i])){

                return true;
            }
        }
        return false;
    }

    public void addEmpleados(){
        String dniEmpleado = ET_dni.getText().toString();
        String nombreEmpleado = ET_nombre.getText().toString();
        String cargoEmpleado = ET_cargo.getText().toString();
        String notaEmpleado = ET_nota.getText().toString();
        String ingresoMensualEmpleado = ET_ingresoMensual.getText().toString();
        int ingresos= Integer.parseInt(ingresoMensualEmpleado);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbzTzctjS1MR_AGslCn-_urFC_g9aeGV0bMc9afFSJpc7E9mxm8IQo4jVq-kISSbTTL9/exec", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent intent = new Intent(getApplicationContext(), SuccessActivity.class);
                startActivity(intent);
                progressDialog.hide();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                AlertDialog.Builder builder = new AlertDialog.Builder(AddActivity.this);
                builder.setTitle("ERROR");
                builder.setMessage("Lo sentimos, pero ha ocurrido un error al insertar, disculpe las molestias.");
                builder.setPositiveButton("Aceptar", null);
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams(){
                Map <String, String> params = new HashMap<>();
                params.put("action", "addEmpleado");
                params.put("dni", dniEmpleado);
                params.put("nombre",nombreEmpleado);
                params.put("cargo", cargoEmpleado);
                params.put("nota", notaEmpleado);
                params.put("ingreso_mensual", ingresoMensualEmpleado);
                params.put("ingreso_trimestral", String.valueOf(ingresos*3));
                params.put("ingreso_anual",  String.valueOf(ingresos*12));

                return params;
            }
        };

        int socketTimeOut = 50000;
        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut,0,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void rellenarLista(){
            String url="https://script.google.com/macros/s/AKfycbzRbLRVoqLKMTmauFs1GCfAoGFF5FpP9KJUVQqO5y7PeCZ_jPHIBafh_dPfT9v3NI6P/exec?action=getEmpleados";
            JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        JSONArray jsonArray= response.getJSONArray("items");

                        //recorre todos los objetos del array
                        for (int i=0; i<jsonArray.length();i++){
                            JSONObject jsonObject = jsonArray.getJSONObject(i);


                            //Columnas
                            String dniEmpleado =jsonObject.getString("dni");
                            ArrayDeEmpleados[i] = dniEmpleado;




                        }


                    } catch (JSONException e) {
                        Toast.makeText(AddActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(AddActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            );

            RequestQueue queue= Volley.newRequestQueue(this);
            queue.add(jsonObjectRequest);

        }

    public boolean listaLlena(){
        int contador=0;
        for (int i=0;i<ArrayDeEmpleados.length;i++){
            if (ArrayDeEmpleados[i]!=null){
                contador++;
            }
        }
        if (contador==20){
            return true;
        }
        return false;
    }
    }


