package com.example.ager;

import java.io.Serializable;

public class ParkingDataModel implements Serializable {
    private String idPlaza,nombre,precio,particular,ingreso_mensual,ingreso_trimestral,ingreso_anual;

    public ParkingDataModel(String idPlaza, String nombre, String precio, String particular) {
        this.idPlaza = idPlaza;
        this.nombre = nombre;
        this.precio = precio;
        this.particular = particular;
    }

    public ParkingDataModel(String idPlaza, String nombre, String precio, String particular, String ingreso_mensual, String ingreso_trimestral, String ingreso_anual) {
        this.idPlaza = idPlaza;
        this.nombre = nombre;
        this.precio = precio;
        this.particular = particular;
        this.ingreso_mensual = ingreso_mensual;
        this.ingreso_trimestral = ingreso_trimestral;
        this.ingreso_anual = ingreso_anual;
    }

    public String getIngreso_mensual() {
        return ingreso_mensual;
    }

    public void setIngreso_mensual(String ingreso_mensual) {
        this.ingreso_mensual = ingreso_mensual;
    }

    public String getIngreso_trimestral() {
        return ingreso_trimestral;
    }

    public void setIngreso_trimestral(String ingreso_trimestral) {
        this.ingreso_trimestral = ingreso_trimestral;
    }

    public String getIngreso_anual() {
        return ingreso_anual;
    }

    public void setIngreso_anual(String ingreso_anual) {
        this.ingreso_anual = ingreso_anual;
    }

    public ParkingDataModel() {

    }

    public String getIdPlaza() {
        return idPlaza;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPrecio() {
        return precio;
    }

    public String getParticular() {
        return particular;
    }

    public void setIdPlaza(String idPlaza) {
        this.idPlaza = idPlaza;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public void setParticular(String particular) {
        this.particular = particular;
    }
}
