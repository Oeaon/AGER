package com.example.ager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.ager.databinding.ActivityBeneficiosBinding;
import com.example.ager.databinding.ActivityEmployersBinding;
import com.example.ager.databinding.ActivityMainBinding;
import com.example.ager.databinding.ActivityParticularesBinding;
import com.example.ager.databinding.ActivityTotalBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TotalActivity extends AppCompatActivity {

    ActivityTotalBinding binding;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbxIm0I5XJ_CaRhxlkvvNuVFGUoWacrHAVULFty25qUUoN6XYFJTKJlMFc_5_l9KZQz3/exec?action=getPrecioTotal";

    private Adaptador adaptador;

    private ParkingDataModel parkingDataModel;

    Button btnMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTotalBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        adaptador= new Adaptador(this);

        binding.TotalDataRecycler.setAdapter(adaptador);
        binding.TotalDataRecycler.setLayoutManager(new LinearLayoutManager(this));

        btnMenu = findViewById(R.id.btn_menuTotal);


        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (TotalActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


        getDataTotal();
    }



    private void getDataTotal(){
        String url=SCRIPT_WEB_URL;
        JsonObjectRequest  jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("items");

                    //recorre todos los objetos del array
                    for (int i=0; i<jsonArray.length()-1;i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        //Columnas
                        String nombre = jsonObject.getString("nombre");
                        String precioTotal = jsonObject.getString("precio_total");

                        ParkingDataModel parkingDataModel = new ParkingDataModel(nombre,"",precioTotal+"€","");

                        adaptador.addModel(parkingDataModel);

                    }


                } catch (JSONException e) {
                    Toast.makeText(TotalActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(TotalActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

    }

}