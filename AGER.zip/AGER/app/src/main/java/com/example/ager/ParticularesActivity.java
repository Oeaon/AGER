package com.example.ager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.ager.databinding.ActivityEmployersBinding;
import com.example.ager.databinding.ActivityMainBinding;
import com.example.ager.databinding.ActivityParticularesBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ParticularesActivity extends AppCompatActivity {

        ActivityParticularesBinding binding;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbwqTV1a7EtVBXZvKLOwAAWq2l1wTMe6TKjsl-ioNSefHIfsUYl7i9H4Sd14DoatuZX-/exec?action=getPersonas";

    private Adaptador adaptador;

    private ParkingDataModel parkingDataModel;

    Button btnMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityParticularesBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        adaptador= new Adaptador(this);

        binding.ParticularesDataRecycler.setAdapter(adaptador);
        binding.ParticularesDataRecycler.setLayoutManager(new LinearLayoutManager(this));

        btnMenu = findViewById(R.id.btn_menuParticular);


        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (ParticularesActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


        getDataParticulares();
    }



    private void getDataParticulares(){
        String url=SCRIPT_WEB_URL;
        JsonObjectRequest  jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("items");

                    //recorre todos los objetos del array
                    for (int i=0; i<jsonArray.length();i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        //Columnas
                        String idPlaza = jsonObject.getString("idPlaza");
                        String nombre = jsonObject.getString("nombre");
                        String precio = jsonObject.getString("precio");


                        ParkingDataModel parkingDataModel = new ParkingDataModel("ID plaza:  " +idPlaza,"","Propietario:  "+nombre,"","Precio:  "+precio+"€","","Tipo: PARTICULAR");

                        adaptador.addModel(parkingDataModel);

                    }


                } catch (JSONException e) {
                    Toast.makeText(ParticularesActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ParticularesActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

    }

}