package com.example.ager;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    boolean repetido=false;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbx-FIZtKGet1gRH1J88EA1q3V80PsJyzQv4RAenM4AYxdzJa3YL7EBwUqwn-myRlVXu/exec?action=getParking";

    int [] ArrayDePlazas= new int[200];

    EditText etIDParking, etNombreParking, etPrecioParking;

    RadioButton rbParticular,rbEmpresa;
    Button btnInsertar, btnParking,btnBeneficios,btnEmpleados;

    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        rellenarLista();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etIDParking= findViewById(R.id.ET_idParking);
        etNombreParking = findViewById(R.id.ET_nombreCliente);
        etPrecioParking= findViewById(R.id.ET_precioCliente);



        rbParticular= findViewById(R.id.rb_particular);
        rbEmpresa = findViewById(R.id.rb_empresa);

        btnInsertar = findViewById(R.id.btn_insertar);
        btnParking = findViewById(R.id.btn_parking);
        btnBeneficios=findViewById(R.id.btn_beneficios);
        btnEmpleados= findViewById(R.id.btn_empleados);

        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("Insertando...");

       btnInsertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //ALERT DIALOG

                if (etIDParking.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Indique el número del parking a alquilar, por favor.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();

                }

                else if (Integer.parseInt(etIDParking.getText().toString())>200){
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("El NÚMERO de la plaza de parking es incorrecto.\nPor favor, recuerde que nuestro límite de plazas es de 200.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }

                else if (getRepetido()){

                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("CUIDADO");
                    builder.setMessage("Lo sentimos, pero el número de la plaza está ya está reservada.\nPor favor, inténtelo con otra.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }



                else if (etNombreParking.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene el nombre del cliente, por favor.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }

                else if (etPrecioParking.getText().toString().isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene el precio a cobrar, por favor. ");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }


                 if (etIDParking.getText().toString().length()>0&&etNombreParking.getText().toString().length()>0 && etPrecioParking.getText().toString().length()>0&&Integer.parseInt(etIDParking.getText().toString())<=200&&!getRepetido()){
                     progressDialog.show();
                     addParking();
                     rellenarLista();
                }



            }
        });

       btnParking.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent (MainActivity.this, EmployersActivity.class);
               startActivity(intent);
           }
       });

       btnBeneficios.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent (MainActivity.this, BeneficiosActivity.class);
               startActivity(intent);
           }
       });

       btnEmpleados.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent (MainActivity.this, TrabajadoresActivity.class);
               startActivity(intent);
           }
       });
    }




    //MÉTODOS
    public boolean getRepetido(){
        for (int i=0; i<ArrayDePlazas.length;i++){
            if (Integer.parseInt(etIDParking.getText().toString())==ArrayDePlazas[i]){

                return true;
            }
        }
        return false;
    }

    public void addParking(){
        String idPlaza = etIDParking.getText().toString();
        String nombrePlaza = etNombreParking.getText().toString();
        String precioPlaza = etPrecioParking.getText().toString();

        String personalPlaza = "";
        if (rbParticular.isChecked()){
            personalPlaza = "VERDADERO";
       }
        else{
            personalPlaza = "FALSO";
        }
        String finalPersonalPlaza = personalPlaza;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbwTv7k_OhwOu1XqzfdtdKrVa_i9MkdvZuVWlrR7-N4qugXNGK_amTYFbZSLaNFvyr8E/exec", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent intent = new Intent(getApplicationContext(), SuccessActivity.class);
                startActivity(intent);
                progressDialog.hide();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("ERROR");
                builder.setMessage("Lo sentimos, pero ha ocurrido un error al insertar, disculpe las molestias.");
                builder.setPositiveButton("Aceptar", null);
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams(){
                Map <String, String> params = new HashMap<>();
                params.put("action", "addParking");
                params.put("idPlaza", idPlaza);
                params.put("nombre",nombrePlaza);
                params.put("precio", precioPlaza);
                params.put("particular", finalPersonalPlaza);

                return params;
            }
        };

        int socketTimeOut = 50000;
        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut,0,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void rellenarLista(){
            String url=SCRIPT_WEB_URL;
            JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        JSONArray jsonArray= response.getJSONArray("items");

                        //recorre todos los objetos del array
                        for (int i=0; i<jsonArray.length();i++){
                            JSONObject jsonObject = jsonArray.getJSONObject(i);


                            //Columnas
                            String idPlaza =jsonObject.getString("idPlaza");
                            ArrayDePlazas[i] =Integer.parseInt(idPlaza);




                        }


                    } catch (JSONException e) {
                        Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            );

            RequestQueue queue= Volley.newRequestQueue(this);
            queue.add(jsonObjectRequest);

        }

    }
