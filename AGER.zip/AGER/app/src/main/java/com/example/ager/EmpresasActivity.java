package com.example.ager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.ager.databinding.ActivityEmployersBinding;
import com.example.ager.databinding.ActivityEmpresasBinding;
import com.example.ager.databinding.ActivityMainBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EmpresasActivity extends AppCompatActivity {

    ActivityEmpresasBinding binding;

    private String SCRIPT_WEB_URL = "https://script.google.com/macros/s/AKfycbw1Rn6RWvKe0XJi0rAVC77V4aWofaKn8VyyMu-PA9D5D_KO-hEz0HgZbcxENWS4X4si/exec?action=getEmpresas";

    private Adaptador adaptador;

    private ParkingDataModel parkingDataModel;

    Button btnMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEmpresasBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        adaptador= new Adaptador(this);

        binding.EmpresasDataRecycler.setAdapter(adaptador);
        binding.EmpresasDataRecycler.setLayoutManager(new LinearLayoutManager(this));

        btnMenu = findViewById(R.id.btn_menuEmpresas);


        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (EmpresasActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        getDataEmpresas();
    }



    private void getDataEmpresas(){
        String url=SCRIPT_WEB_URL;
        JsonObjectRequest  jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("items");

                    //recorre todos los objetos del array
                    for (int i=0; i<jsonArray.length();i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        //Columnas
                        String idPlaza = jsonObject.getString("idPlaza");
                        String nombre = jsonObject.getString("nombre");
                        String precio = jsonObject.getString("precio");


                        ParkingDataModel parkingDataModel = new ParkingDataModel("ID plaza:  " +idPlaza,"","Propietario:  "+nombre,"","Precio:  "+precio+"€","","Tipo: EMPRESA");

                        adaptador.addModel(parkingDataModel);

                    }


                } catch (JSONException e) {
                    Toast.makeText(EmpresasActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(EmpresasActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

    }

}