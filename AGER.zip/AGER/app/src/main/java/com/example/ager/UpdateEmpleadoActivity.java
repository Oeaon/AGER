package com.example.ager;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ager.databinding.ActivityUpdateDataParkingBinding;
import com.example.ager.databinding.ActivityUpdateEmpleadoBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UpdateEmpleadoActivity extends AppCompatActivity {

    ActivityUpdateEmpleadoBinding binding;

    private String SCRIPT_GET_EMPLEADOS="https://script.google.com/macros/s/AKfycbwk56qyfoseOB4w1djNmE33jft0ZNBBQ6nhlXTfWIETPt6e3ddr-NPJ_W8AWcaoH5xk/exec?action=getEmpleados";
    private String SCRIPT_UPDATE_EMPLEADOS="https://script.google.com/macros/s/AKfycbx5yAer07zXe1NU7gRM7TNcTvzoSR4ITEnOiNkZIFdA-c9LHDF5gtKK-SWx1b_s3hTC/exec?action=updateEmpleado";



    String [] ArrayDeEmpleados= new String[20];

    boolean flagEsta;

    Button btn_actualizar,btn_menu;

    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityUpdateEmpleadoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //Se rellena la lista
        rellenarLista();

        btn_actualizar=findViewById(R.id.btn_ActualizarEmpleadoUpdate);
        btn_menu=findViewById(R.id.btn_volverMenuEmpleadoUpdate);

        progressDialog = new ProgressDialog(UpdateEmpleadoActivity.this);
        progressDialog.setMessage("Actualizando...");

        btn_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                progressDialog.hide();
            }
        });

        btn_actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dniUpdate= binding.editTextDNI.getText().toString();
                String nombreUpdate= binding.editTextNombrEmpleadoUpdate.getText().toString();
                String cargoUpdate= binding.editTextCargoEmpleadoUpdate.getText().toString();
                String notaUpdate= binding.editTextNotaEmpleadoUpdate.getText().toString();
                String sueldo=binding.editTextSueldoEmpleadoUpdate.getText().toString();


                if (!dniUpdate.isEmpty()){
                    comprobarDni(dniUpdate);
                }

                if (dniUpdate.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEmpleadoActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Indique el DNI del trabajador, por favor.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();

                }
                else if (dniUpdate.length()>9){
                    AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEmpleadoActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("El DNI supera las 9 cifras.\nPor favor, no supere dicho límite.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if (dniUpdate.length()<9){
                    AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEmpleadoActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("El DNI no llega a las 9 cifras.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }

                else if (!flagEsta){

                    AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEmpleadoActivity.this);
                    builder.setTitle("CUIDADO");
                    builder.setMessage("Lo sentimos, pero el/la trabajador/a introducida NO está contratado/a.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }



                else if (nombreUpdate.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEmpleadoActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene el nombre del trabajador, por favor.");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }

                else if (cargoUpdate.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEmpleadoActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene el cargo a asociar, por favor. ");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if (notaUpdate.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEmpleadoActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene una nota acerda del trabajador, por favor. ");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if (sueldo.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEmpleadoActivity.this);
                    builder.setTitle("ATENCIÓN");
                    builder.setMessage("Rellene un sueldo para el trabajador, por favor. ");
                    builder.setPositiveButton("Aceptar", null);

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }


                if (dniUpdate.length()>0&&nombreUpdate.length()>0 && cargoUpdate.length()>0&& notaUpdate.length()>0&& sueldo.length()>0&&dniUpdate.length()<=9&&flagEsta){
                    progressDialog.show();
                    updateDataEmpleado(dniUpdate,nombreUpdate,cargoUpdate,notaUpdate,Integer.parseInt(sueldo));
                    rellenarLista();
                }
            }
        });
    }

    private void updateDataEmpleado(String dni,String nombre, String cargo, String nota,int sueldo) {
        String url=SCRIPT_UPDATE_EMPLEADOS+"&dni="+dni+"&nombre="+nombre+"&cargo="+cargo+"&nota="+nota+"&ingreso_mensual="+sueldo+"&ingreso_trimestral="+String.valueOf(sueldo*3)+"&ingreso_anual="+String.valueOf(sueldo*12);

        StringRequest stringRequest= new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent intent = new Intent(getApplicationContext(), UpdateSuccessActivity.class);
                startActivity(intent);
                progressDialog.hide();
                Toast.makeText(UpdateEmpleadoActivity.this,response,Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(UpdateEmpleadoActivity.this,error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    public void rellenarLista(){
        String url=SCRIPT_GET_EMPLEADOS;
        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray= response.getJSONArray("items");

                    //recorre todos los objetos del array
                    for (int i=0; i<jsonArray.length();i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);


                        //Columnas
                        String dniEmpleado =jsonObject.getString("dni");
                        ArrayDeEmpleados[i] = dniEmpleado;




                    }


                } catch (JSONException e) {
                    Toast.makeText(UpdateEmpleadoActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();



                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(UpdateEmpleadoActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        );

        RequestQueue queue= Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

    }

    public boolean comprobarDni(String dni){
        for (int i=0; i<ArrayDeEmpleados.length;i++){
            if (dni.equalsIgnoreCase(ArrayDeEmpleados[i])){
                flagEsta=true;
                return flagEsta;
            }else {
                flagEsta=false;
            }
        }
        return flagEsta;
    }
}